# Bootstrap 3 login, register and forgot password templates.
Basic bootstrap 3 login, register and forgot password templates. This is simple project only. Check it out!

Login template:

![alt text](image/login-form.PNG "Login template")

Register template:

![alt text](image/register-form.PNG "Register template")

Forgot password template:

![alt text](image/forgot-pswd-form.PNG "Forgot password template")

For more tutorial please visit: https://jaironlanda.com
